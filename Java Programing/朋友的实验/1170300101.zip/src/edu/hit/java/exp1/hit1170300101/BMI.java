package edu.hit.java.exp1.hit1170300101;

import java.util.*;
import java.math.*;

public class BMI {

    /**
     * @name main
     * @function run the function menu
     * @author Liu Qinglin
     * @version 1.2(1.0 died of using "class Student" and 1.1 was gone for not
     * using function menu)
     */
    public static void main(String[] args) {
        String[] ids = null,names = null;
        float[] heights = null,weights = null,bmis = null;
        int[] sortedIndex = null;
        menu(ids,names,heights,weights,bmis,sortedIndex);
    }

    /**
     * @name checkHealth
     * @function check where one's bmi lies
     * @author Liu Qinglin
     * @version 1.0
     * @param bmi
     * @return String type standing for the conditon
     */
    public static String checkHealth(float bmi) {
        if (bmi <= 18.5) {
            return "Underweight";
        } else if (bmi <= 23) {
            return "Normal Range";
        } else if (bmi <= 25) {
            return "Overweight--At Risk";
        } else if (bmi <= 30) {
            return "Overweight--Moderately Obese";
        } else {
            return "Severely Obese";
        }
    }

    /**
     * @name round
     * @function make the float type rounded up to 2 decimal places
     * @author Liu Qinglin
     * @version 1.0
     * @param f
     * @return String type standing for the conditon
     */
    public static float round(float f) {
        BigDecimal ff = new BigDecimal(f);
        float fff = ff.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
        return fff;
    }

    /**
     * @param Num
     * @param ids
     * @param names
     * @param heights
     * @param weights
     * @param bmis
     * @name inputStudents
     * @function input students' information ,calculate the bmi and output the
     * bmi's condition
     * @author Liu Qinglin
     * @version 1.0
     */
    public static void inputStudents(int Num, String[] ids, String[] names, float[] heights,
            float[] weights, float[] bmis) {
        Scanner cin = new Scanner(System.in);
        for (int i = 1; i <= Num; i++) {
            System.out.println("ID:");
            ids[i] = cin.nextLine();
            System.out.println("Name:");
            names[i] = cin.nextLine();
            System.out.println("Height:");
            float tmp = cin.nextFloat();
            heights[i] = (float) round(tmp);
            System.out.println("Weight:");
            tmp = cin.nextFloat();
            weights[i] = (float) round(tmp);
            cin.nextLine();
            if (heights[i] != 0) {
                tmp = weights[i] / heights[i] / heights[i];
                bmis[i] = (float) round(tmp);
            } else {
                bmis[i] = 0.00f;
            }
            System.out.println(checkHealth(bmis[i]));
        }
    }

    /**
     * @name printHint
     * @function print hint on the screen
     * @author Liu Qinglin
     * @version 1.0
     */
    public static void printHint() {
        System.out.println("1.Input Students' Information");
        System.out.println("2.Print Students' Information");
        System.out.println("3.Sort By Ids");
        System.out.println("4.Sort By Names");
        System.out.println("5.Sort By Heights");
        System.out.println("6.Sort By Weights");
        System.out.println("7.Sort By BMIs");
        System.out.println("8.Exit");
    }

    /**
     * @name menu
     * @function operate 8 functions,including input,output,5 kinds of sorts and
     * exit
     * @author Liu Qinglin
     * @version 1.0
     */
    public static void menu(String[] ids,String[] names,float[] heights,float[] weights,
            float[] bmis,int[] sortedIndex) {
        Scanner cin = new Scanner(System.in);
        boolean state = false;
        // this boolean type is used to control when to operate several exit functions
        while (!state) {
            /*
            The biggest loop is to make the operate continuous as long as the value of state is true,
            and the value only changes when function exit is operated.
            First, only function 1 and 8 is allowed to operate, for before 1 is operated, 2 - 7 are not able to operate.
            So, before 1 or 8 is operated, the input only allows value 1 or 8, before which the input is nonstop.
             */
            int tmp = 0;
            while (tmp != 1 && tmp != 8 && !state) {
                printHint();
                // use printHint to print the hint for the first time
                tmp = cin.nextInt();
                // if the value of tmp is 8, get out of every loop
                if (tmp == 8) {
                    state = true;
                    break;
                }
            }
            // if state is equal to true, get out of the loop
            if (state) {
                break;
            }
            // input the number of students before input students' information
            System.out.println("Input The Number Of Students：");
            int Num = cin.nextInt();
            // create the arrays
            ids = new String[Num + 1];
            names = new String[Num + 1];
            heights = new float[Num + 1];
            weights = new float[Num + 1];
            bmis = new float[Num + 1];
            sortedIndex = new int[Num + 1];
            /*
            set the sortedIndex's initial value as 1 - Num, so if execute function 2 before any sort,
            output's order is the same as the input's
             */
            for (int i = 1; i <= Num; i++) {
                sortedIndex[i] = i;
            }
            // execute function inputStudents
            inputStudents(Num, ids, names, heights, weights, bmis);
            // again, execute a nonstop loop, also, the boolean variable state is used to control when to exit
            while (true) {
                printHint();
                tmp = cin.nextInt();
                // tmp is used to control which function to execute, not use case because it takes more code length
                if (tmp == 2) {
                    printStudents(Num, ids, names, heights, weights, bmis, sortedIndex);
                } else if (tmp == 3) {
                    sortedIndex = sortByIds(Num, ids);
                } else if (tmp == 4) {
                    sortedIndex = sortByNames(Num, names);
                } else if (tmp == 5) {
                    sortedIndex = sortByHeights(Num, heights);
                } else if (tmp == 6) {
                    sortedIndex = sortByWeights(Num, weights);
                } else if (tmp == 7) {
                    sortedIndex = sortByBmis(Num, bmis);
                } else if (tmp == 8) {
                    state = true;
                    break;
                }
            }
            if (state) {
                break;
            }
        }
    }

    /**
     * @name quicksortByString
     * @function quicksort the tmp array
     * @author Liu Qinglin
     * @version 1.0
     * @param beg,ed,tmp,index
     */
    public static void quicksortByString(int beg, int ed, String[] tmp, int[] index) {
        if (beg >= ed) {
            return;
        }
        // if beg >= ed, the sort is to an end, and the recursion is over
        int l = beg, r = ed;
        // choose a random pivot so that the algorithm cannot be slowed down by some special cases
        int p = (int) (Math.random() * (ed - beg + 1) + beg);
        String key = tmp[p];
        // get the random pivot
        int key1 = index[p];
        // pitch on the corresponding index
        String t = tmp[p];
        int t1 = index[p];
        tmp[p] = tmp[l];
        index[p] = index[l];
        tmp[l] = t;
        index[l] = t1;
        // switch the left element and the random pivot, and the same is true of the index
        while (l < r) {
            while (l < r && key.compareTo(tmp[r]) <= 0) {
                r--;
            }
            // find the first element smaller than the random pivot from the right side
            if (l < r) {
                tmp[l] = tmp[r];
                index[l] = index[r];
                l++;
            }
            // move it and its index and go on
            while (l < r && key.compareTo(tmp[l]) >= 0) {
                l++;
            }
            // find the first element bigger than the random pivot from the left side
            if (l < r) {
                tmp[r] = tmp[l];
                index[r] = index[l];
                r--;
            }
            // move it and its index and go on
        }
        tmp[l] = key;
        index[l] = key1;
        // set the remaining element as the key, and the index
        quicksortByString(beg, l - 1, tmp, index); //recursion
        quicksortByString(l + 1, ed, tmp, index); //recursion
    }

    /**
     * @name quicksortByFloat
     * @function quicksort the tmp array
     * @author Liu Qinglin
     * @version 1.0
     * @param beg,ed,tmp,index
     */
    public static void quicksortByFloat(int beg, int ed, float[] tmp, int[] index) {
        if (beg >= ed) {
            return;
        }
        // if beg >= ed, the sort is to an end, and the recursion is over
        int l = beg, r = ed;
        // choose a random pivot so that the algorithm cannot be slowed down by some special cases
        int p = (int) (Math.random() * (ed - beg + 1) + beg);
        float key = tmp[p];
        // get the random pivot
        int key1 = index[p];
        // pitch on the corresponding index
        float t = tmp[p];
        int t1 = index[p];
        tmp[p] = tmp[l];
        index[p] = index[l];
        tmp[l] = t;
        index[l] = t1;
        // switch the left element and the random pivot, and the same is true of the index
        while (l < r) {
            while (l < r && key <= tmp[r]) {
                r--;
            }
            // find the first element smaller than the random pivot from the right side
            if (l < r) {
                tmp[l] = tmp[r];
                index[l] = index[r];
                l++;
            }
            // move it and its index and go on
            while (l < r && key >= tmp[l]) {
                l++;
            }
            // find the first element bigger than the random pivot from the left side
            if (l < r) {
                tmp[r] = tmp[l];
                index[r] = index[l];
                r--;
            }
            // move it and its index and go on
        }
        tmp[l] = key;
        index[l] = key1;
        // set the remaining element as the key, and the index
        quicksortByFloat(beg, l - 1, tmp, index); //recursion
        quicksortByFloat(l + 1, ed, tmp, index); //recursion
    }

    /**
     * @name SortByIds
     * @function quicksort and return the index array
     * @author Liu Qinglin
     * @version 1.0
     * @param Num,ids
     * @return an index array
     */
    public static int[] sortByIds(int Num, String[] ids) {
        String[] tmp = new String[Num + 1];
        for (int i = 1; i <= Num; i++) {
            tmp[i] = ids[i];
        }
        int[] index = new int[Num + 1];
        for (int i = 1; i <= Num; i++) {
            index[i] = i;
        }
        quicksortByString(1, Num, tmp, index);
        return index;
    }

    /**
     * @name SortByNames
     * @function quicksort and return the index array
     * @author Liu Qinglin
     * @version 1.0
     * @param Num,ids
     * @return an index array
     */
    public static int[] sortByNames(int Num, String[] names) {
        String[] tmp = new String[Num + 1];
        for (int i = 1; i <= Num; i++) {
            tmp[i] = names[i];
        }
        int[] index = new int[Num + 1];
        for (int i = 1; i <= Num; i++) {
            index[i] = i;
        }
        quicksortByString(1, Num, tmp, index);
        return index;
    }

    /**
     * @name SortByHeights
     * @function quicksort and return the index array
     * @author Liu Qinglin
     * @version 1.0
     * @param Num,ids
     * @return an index array
     */
    public static int[] sortByHeights(int Num, float[] heights) {
        float[] tmp = new float[Num + 1];
        for (int i = 1; i <= Num; i++) {
            tmp[i] = heights[i];
        }
        int[] index = new int[Num + 1];
        for (int i = 1; i <= Num; i++) {
            index[i] = i;
        }
        quicksortByFloat(1, Num, tmp, index);
        return index;
    }

    /**
     * @name SortByWeights
     * @function quicksort and return the index array
     * @author Liu Qinglin
     * @version 1.0
     * @param Num,ids
     * @return an index array
     */
    public static int[] sortByWeights(int Num, float[] weights) {
        float[] tmp = new float[Num + 1];
        for (int i = 1; i <= Num; i++) {
            tmp[i] = weights[i];
        }
        int[] index = new int[Num + 1];
        for (int i = 1; i <= Num; i++) {
            index[i] = i;
        }
        quicksortByFloat(1, Num, tmp, index);
        return index;
    }

    /**
     * @name SortByBmis
     * @function quicksort and return the index array
     * @author Liu Qinglin
     * @version 1.0
     * @param Num,ids
     * @return an index array
     */
    public static int[] sortByBmis(int Num, float[] bmis) {
        float[] tmp = new float[Num + 1];
        for (int i = 1; i <= Num; i++) {
            tmp[i] = bmis[i];
        }
        int[] index = new int[Num + 1];
        for (int i = 1; i <= Num; i++) {
            index[i] = i;
        }
        quicksortByFloat(1, Num, tmp, index);
        return index;
    }

    /**
     * @name printStudents
     * @function print the Students' information after sort (or not)
     * @author Liu Qinglin
     * @version 1.0
     * @param Num,ids,names,heights,weights,bmis,sortedIndex
     */
    public static void printStudents(int Num, String[] ids, String[] names, float[] heights,
            float[] weights, float[] bmis, int[] sortedIndex) {
        for (int i = 1; i <= Num; i++) {
            System.out.println(ids[sortedIndex[i]] + "\t" + names[sortedIndex[i]] + "\t" + round(heights[sortedIndex[i]])
                    + "\t" + round(weights[sortedIndex[i]]) + "\t" + round(bmis[sortedIndex[i]]));
        }
    }
}
