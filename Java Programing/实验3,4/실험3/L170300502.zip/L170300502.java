package edu.hit.java.exp3; 
import java.util.ArrayList; 
import java.util.Arrays; 
import java.util.Comparator;
import java.util.Random;
import java.util.Scanner; 
public class L170300502
{  
   static Scanner in = new Scanner(System.in);   
    
   public static final class Student { 
      private String id; 
      private String name; 
      private float height; 
      private float weight; 
      private float bmi; 
      public Student() {} 
      
      public float getBmi() { 
         return bmi; 
      } 
      public String getId() { 
         return id; 
      } 
      public void setId(String id) { 
         this.id = id; 
      } 
      public String getName() { 
         return name; 
      } 
      public void setName(String name) { 
         this.name = name; 
      } 
      public void setHeight(float height) { 
         this.height = height; 
      } 
      public void setBmi(float bmi) { 
         this.bmi = bmi; 
      } 
      public float getHeight() { 
         return height; 
      } 
      public float getWeight() { 
         return weight; 
      } 
      public void setWeight(float weight) { 
         this.weight = weight; 
      } 
      public void getStatics(float height , float weight) {
    	  
      }
   } 
   
   private static final ArrayList<Student> students = new ArrayList<>(); 
    
   private static final Student[] students2 = new Student[3000]; 
   public static void main(String[] args) 
   {  
      System.out.println("Welcome To The Students' Healthy Information System!\n");  
      menu();    
      in.close();  
   }    
   public static void menu()  
   {    
      
      while(true) 
      {    
         System.out.println("1. Create students at random"); 
         System.out.println("2. Print students' information"); 
         System.out.println("3. Sort the students by IDs"); 
         System.out.println("4. Sort the students by Names"); 
         System.out.println("5. Sort the students by Heights"); 
         System.out.println("6. Sort the students by Weights"); 
         System.out.println("7. Sort the students by BMIs");
         System.out.println("8. print statics");
         System.out.println("9. Exit the students' healthy information system\n"); 
         System.out.print("Please input the number you want to do: ");    
         switch(Integer.parseInt(in.nextLine()))   
         {    
            case 1: inputStudents(); break;    
            case 2: printStudents(); break;    
            case 3: sortByIDs(); break;    
            case 4: sortByNames(); break;    
            case 5: sortByHeights(); break;    
            case 6: sortByWeights(); break;    
            case 7: sortByBMI(); break;
            case 8: statics(); break;
            case 9: System.out.println("Goodbye! Thank you for using."); return;    
            default: System.out.print("You input the wrong number. Please input again."); break;  
         }   
         System.out.println(); 
      } 
   }    
   public static void inputStudents()  
   {  
	  
	  Random ran = new Random();
      System.out.print("Please input the numbers of the students: ");  
      int from = students.size() + 1; 
      int to = from + Integer.parseInt(in.nextLine()); 
      System.out.println();      
      for(int i = from; i < to; i++)   
      { 
         Student student = new Student(); 
         
         student.setId("Hit"+ (1170000000 + ran.nextInt(1000000))); 
         StringBuffer ch = new StringBuffer();            
			for (int j = 0; j < 3; j++) {                
				if (j == 0) {                     
					ch.append(String.valueOf((char) Math.round(Math.random() * 25 + 65)));
					
					continue;
				}
				
				ch.append(String.valueOf((char) Math.round(Math.random() * 25 + 97))); 
			}
			 
         student.setName(ch.toString());      
          
         student.setHeight((float)  (Math.random()*200 + 100));   
             
         student.setWeight((float) (Math.random()*100 + 30));       
            
         student.setBmi(calcBMI(student.getWeight(), student.getHeight()));  
         
         
         
         students2[i-1] = student; 
         
         students.add(student); 
      }      
   } 
   public static float calcBMI(float weight, float height) { 
      return weight / ((height/100) * (height/100)); 
   } 
   public static void checkHealth(float bmis)  
   {   
      if(bmis <= 18.5)    
      System.out.println("Underweight");   
      else if(bmis <= 23)    
      System.out.println("Normal Range");   
      else if(bmis <= 25)    
      System.out.println("Overweight--At Risk");  
      else if(bmis <= 30)    
      System.out.println("Overweight--Moderately Obese");   
      else    
      System.out.println("Overweight--Severely Obese"); 
   }    
   
   public static void printStudents()  
   {   
	   Student student = new Student(); 
      for(int i = 0; i < students.size(); i++)   {
    	
    	  
    	  
      System.out.printf(students.get(i).getId() + "\t" + students.get(i).getName() + "\t%.2f\t%.2f\t%.2f  ", students.get(i).getHeight(), students.get(i).getWeight(), students.get(i).getBmi());
      checkHealth(students.get(i).getBmi());
      System.out.println("\n");
          
         
      }
   }
   public static void statics()
   {
	   float averh = 0;
	   float averw = 0;
	   float averb = 0;
	   float bigh = students.get(0).getHeight();
	   float bigw = students.get(0).getWeight();
	   float bigb = students.get(0).getBmi();
	   float smallw = students.get(0).getHeight();
	   float smallh = students.get(0).getWeight();
	   float smallb = students.get(0).getBmi();
	   for(int i=0 ; i < students.size(); i++) {
		   averh += students.get(i).getHeight();
	    	  averw += students.get(i).getWeight();
	    	  averb += students.get(i).getBmi();
	    	  for(int j=1 ; j<students.size(); j++) {
	    		  if(students.get(j).getHeight()>students.get(i).getHeight()) {
	    			  bigh = students.get(j).getHeight();
	    		  }
	    	  }
	    	  for(int j=1 ; j<students.size(); j++) {
	    		  if(students.get(j).getWeight()>students.get(i).getWeight()) {
	    			  bigh = students.get(j).getWeight();
	    		  }
	    	  }
	    	  for(int j=1 ; j<students.size(); j++) {
	    		  if(students.get(j).getBmi()>students.get(i).getBmi()) {
	    			  bigh = students.get(j).getBmi();
	    		  }
	    	  }
	    	  for(int j=1 ; j<students.size(); j++) {
	    		  if(students.get(j).getBmi()<students.get(i).getBmi()) {
	    			  smallb = students.get(j).getBmi();
	    		  }
	    	  }
	    	  for(int j=1 ; j<students.size(); j++) {
	    		  if(students.get(j).getHeight()<students.get(i).getHeight()) {
	    			  smallh = students.get(j).getHeight();
	    		  }
	    	  }
	    	  for(int j=1 ; j<students.size(); j++) {
	    		  if(students.get(j).getWeight()<students.get(i).getWeight()) {
	    			  smallw = students.get(j).getWeight();
	    		  }
	    	  }


	   }
	   System.out.println("average of height: "+averh +"\n"+"biggest of height: " + bigh + "\n" + "smallest of height: " + smallh);
	   System.out.println("average of weight: "+averw +"\n"+"biggest of weight: " + bigw + "\n" + "smallest of weight: " + smallw);
	   System.out.println("average of bmi: "+averb+"\n"+"biggest of bmi: " + bigb + "\n" + "smallest of bmi: " + smallb);
   }
      
   public static void sortByIDs()  
   {  
      students.sort(Comparator.comparing(Student::getId)); 
      
      Arrays.sort(students2, 0, students.size(), Comparator.comparing(Student::getId)); 
   }    
   public static void sortByNames()  
   {  
      students.sort(Comparator.comparing(Student::getName)); 
      Arrays.sort(students2, 0, students.size(), Comparator.comparing(Student::getName)); 
   }    
   public static void sortByHeights()  
   {   
      students.sort(Comparator.comparing(Student::getHeight)); 
      Arrays.sort(students2, 0, students.size(), Comparator.comparing(Student::getHeight)); 
   }  
   public static void sortByWeights()  
   {  
      students.sort(Comparator.comparing(Student::getWeight)); 
      Arrays.sort(students2, 0, students.size(), Comparator.comparing(Student::getWeight)); 
   } 
   public static void sortByBMI()  
   {   
      students.sort(Comparator.comparing(Student::getBmi)); 
      Arrays.sort(students2, 0, students.size(), Comparator.comparing(Student::getBmi)); 
   }
   
   

public boolean isExists() {         
	for (Student student : this.students) {             
	if (student != null)               


       return true;     }
	return false;
}
}
