/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.hit.java.exp4.hit1170300823;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.IntervalXYDataset;
import org.jfree.data.xy.XYBarDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JEditorPane;
import javax.swing.JToolBar;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/*
将bmi值根据值的大小分段计数，便于之后画图
 */
public class GUIFileBMI extends JFrame {

    public static IntervalXYDataset BmiDataset() {
        XYSeriesCollection seriesCollection = new XYSeriesCollection();
        XYSeries series1 = new XYSeries("BMI Statistics");
        int a[] = new int[10];/*定义一个数组，用于记录各个段出现的bmi值个数*/
        for (Student sb : students)/*加强for循环，遍历整个students*/ {
            if (sb.bmi <= 14) {
                a[0]++;
            } else if (sb.bmi > 14 && sb.bmi <= 15) {
                a[1]++;
            } else if (sb.bmi > 15 && sb.bmi <= 16) {
                a[2]++;
            } else if (sb.bmi > 16 && sb.bmi <= 17) {
                a[3]++;
            } else if (sb.bmi > 17 && sb.bmi <= 18) {
                a[4]++;
            } else if (sb.bmi > 18 && sb.bmi <= 19) {
                a[5]++;
            } else if (sb.bmi > 19 && sb.bmi <= 20) {
                a[6]++;
            } else if (sb.bmi > 20 && sb.bmi <= 21) {
                a[7]++;
            } else if (sb.bmi > 21 && sb.bmi <= 22) {
                a[8]++;
            } else {
                a[9]++;
            }
        }/*统计a数组的各个值*/
        series1.add(14, a[0]);
        series1.add(15, a[1]);
        series1.add(16, a[2]);
        series1.add(17, a[3]);
        series1.add(18, a[4]);
        series1.add(19, a[5]);
        series1.add(20, a[6]);
        series1.add(21, a[7]);
        series1.add(22, a[8]);
        series1.add(23, a[9]);
        seriesCollection.addSeries(series1);
        return new XYBarDataset(seriesCollection, 0.9);
    }
    /*定义student的ArrayList以及各个textfield以及Jpanel*/
    public static ArrayList<Student> students = new ArrayList<Student>();
    private JPanel contentPane;
    private JLabel label_2;
    private JTextField textField;
    private JTextField textField_1;
    private JTextField textField_2;
    private JTextField textField_3;

    public ArrayList<Student> readFile(String fileName) {
        File file = new File(fileName);
        BufferedReader reader = null;
        ArrayList<Student> v = new ArrayList<Student>();
        try {
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            while ((tempString = reader.readLine()) != null) {
                String[] a = tempString.split(",");
                Student st = new Student(a[0], a[1], Float.parseFloat(a[2]), Float.parseFloat(a[3]));
                v.add(st);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return v;
    }

    public void saveFile(ArrayList<Student> students, String fileName) {
        try {
            BufferedWriter writer
                    = new BufferedWriter(new FileWriter(fileName, false));
            for (Student st : students) {
                writer.write(String.format("%s,%s,%.2f,%.2f,%.2f,%s\r\n",
                        st.id, st.name, st.height, st.weight, st.bmi, st.health));
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*计算bmi的平均值*/
    public static float Average(List<Student> students) {
        if (null == students || students.isEmpty()) {
            return 0.0f;
        }/*如果没有数据就返回0.0*/
        float sum = 0;
        for (Student s : students) {
            sum += s.bmi;/*对sum进行累加*/
        }
        return sum / students.size();/*返回平均值*/
    }

    /* 计算bmi的中值*/
    public double Middle(List<Student> students) {
        // sort first
        if (null == students || students.isEmpty()) {
            return 0.0f;
        }
        students.sort(new BmiComparator());
        if (0 == students.size() % 2) {
            return (students.get(students.size() / 2 - 1).bmi + students.get(students.size() / 2).bmi) / 2;/*若为偶数，返回中间两个数的平均值*/
        } else {
            return students.get(students.size() / 2).bmi;/*如果为奇数，返回中间的 值*/
        }
    }

    /*计算bmi的众数*/
    public List<Float> Mode(List<Student> students) {
        Map<Double, Integer> map = new HashMap<>();/*定义一个map，将double的值映射成整数*/
        for (Student s : students) {
            if (map.containsKey(s.bmi)) /*获取bmi 的值*/ {
                map.put(s.bmi, map.get(s.bmi) + 1);
            } else {
                map.put(s.bmi, 1);
            }/*插入元素*/
        }
        /*对数出现的次数进行判断*/
        Iterator iterator = map.entrySet().iterator();
        int maxCount = Integer.MIN_VALUE;
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            if (maxCount < (int) entry.getValue()) {
                maxCount = (int) entry.getValue();
            }
        }
        /*如果出现次数都为1，则没有众数*/
        if (1 == maxCount) {
            return null;
        }
        List<Float> list = new ArrayList<>();
        iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            if ((int) entry.getValue() == maxCount) {
                list.add((float) entry.getKey());
            }
        }
        return list;/*返回出现次数相同且不为1的众数*/
    }

    /*计算bmi的方差*/
    public static float Variance(List<Student> students) {
        if (null == students || students.isEmpty()) {
            return 0.0f;
        }
        float sum = 0.0f, average = Average(students);
        for (Student s : students) {
            double x = s.bmi - average;
            sum += x * x;
        }
        return sum / students.size();
    }

    /*对学号是否存在进行判断*/
    private boolean isExists(String id) {
        for (Student s : students) {
            if (id.equals(s.getId())) {
                return true;/*若存在相同的id，返回true，使程序继续产生新的id，直到不重复*/
            }
        }
        return false;/*如果不存在，则产生下一个学生的id*/
    }

    /*下面四个分别生成对于的Pane*/
    private void statics() {
        this.setContentPane(new staticsPanel());
        setVisible(true);
    }

    private void paixu() {
        this.setContentPane(new paixuPanel());
        setVisible(true);
    }

    private void findStudent() {
        this.setContentPane(new FindPanel());
        setVisible(true);
    }

    private void modify() {
        this.setContentPane(new modifyPanel());
        setVisible(true);

    }

    /*定义学生排序的总类*/
    public void sortStudents(Comparator<Student> c) {
        Collections.sort(students, c);
    }

    /*学生按高度进行排序*/
    private class HeightComparator implements Comparator<Student> {

        @Override
        public int compare(Student st1, Student st2) {
            if (st1.getHeight() > st2.getHeight()) {
                return 1;
            } else if (st1.getHeight() < st2.getHeight()) {
                return -1;
            }
            return 0;
        }
    }/*学生1比学生2高返回1，矮返回-1，同样高返回0，用于之后的输出*/
 /*重新写名字对比函数*/
    private class NameComparator implements Comparator<Student> {

        @Override
        public int compare(Student st1, Student st2) {
            return st1.getName().compareTo(st2.getName());
        }
    }

    /*重新写id对比函数*/
    private class IdComparator implements Comparator<Student> {

        @Override
        public int compare(Student st1, Student st2) {
            return st1.getId().compareTo(st2.getId());
        }
    }

    /*重新写体重对比函数*/
    private class WeightComparator implements Comparator<Student> {

        @Override
        public int compare(Student st1, Student st2) {
            if (st1.getWeight() > st2.getWeight()) {
                return 1;
            } else if (st1.getWeight() < st2.getWeight()) {
                return -1;
            }
            return 0;
        }
    }

    /*重新写bmi值对比函数*/
    private class BmiComparator implements Comparator<Student> {

        @Override
        public int compare(Student st1, Student st2) {
            if (st1.getBmi() > st2.getBmi()) {
                return 1;
            } else if (st1.getBmi() < st2.getBmi()) {
                return -1;
            }
            return 0;
        }
    }

    /*定义statics界面的信息*/
    class staticsPanel extends JPanel {

        public staticsPanel() {
            JTextArea textArea = new JTextArea();
            textArea.setBounds(143, 10, 281, 241);/*定义文本框大小*/
            this.add(textArea);/*将文本框添加到界面中*/
            StringBuilder sb = new StringBuilder();/*定义一个字符串，用于存储统计数据的信息*/
            List<Float> mode = Mode(students);
            if (null != mode && !mode.isEmpty())/*对是否存在众数进行判断*/ {
                sb.append(String.format("Average:%.2f\nMiddle:%.2f\n", Average(students), Middle(students)));/*将平均值和中位数传给sb*/
                for (float m : mode) {
                    sb.append(String.format("%.2f ", m));/*将众数传给sb*/
                }
                sb.append(String.format("Variance:%.2f\n", Variance(students)));/*将方差传给sb*/
            } else {
                sb.append(String.format("Average:%.2f\nMiddle:%.2f\nThere is no mode\nVariance:%.2f\n", Average(students), Middle(students), Variance(students)));
            }/*不存在众数则众数一行为there is no mode
             */
            textArea.setText(sb.toString());/*将数据填入文本框中*/
        }
    }

    /*定义排序界面的信息*/
    class paixuPanel extends JPanel {

        public paixuPanel() {
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setBounds(100, 100, 450, 300);
            /*设计按钮*/
            this.setBorder(new EmptyBorder(5, 5, 5, 5));/*设计按钮黑点*/
            setContentPane(this);
            this.setLayout(null);
            JTextArea textArea = new JTextArea();/*定义一个文本框*/
            textArea.setBounds(143, 10, 400, 500);
            JScrollPane jp = new JScrollPane(textArea);
            jp.setBounds(143, 10, 600, 500);/*定义滚动块*/
            this.add(jp);
            JLabel label = new JLabel("\u6392\u5E8F\u9009\u62E9");
            label.setBounds(20, 20, 54, 15);
            this.add(label);
            /*按学号进行排序*/
            JRadioButton radioButton = new JRadioButton("\u5B66\u53F7");
            radioButton.setBounds(20, 41, 121, 23);
            this.add(radioButton);
            radioButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    sortStudents(new IdComparator());

                    StringBuilder sb = new StringBuilder();
                    for (Student st : students) {
                        sb.append(String.format("%s\t%s\t%.2f\t%.2f\t%.2f\t%s\r\n", st.id, st.name, st.height, st.weight, st.bmi, st.health));

                    }

                    textArea.setText(sb.toString());
                }

            });
            /*按姓名进行排序*/
            JRadioButton radioButton_1 = new JRadioButton("\u59D3\u540D");
            radioButton_1.setBounds(20, 66, 121, 23);
            this.add(radioButton_1);
            radioButton_1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    sortStudents(new NameComparator());

                    StringBuilder sb = new StringBuilder();
                    for (Student st : students) {
                        sb.append(String.format("%s\t%s\t%.2f\t%.2f\t%.2f\t%s\r\n", st.id, st.name, st.height, st.weight, st.bmi, st.health));

                    }

                    textArea.setText(sb.toString());
                }

            });
            /*按身高进行排序*/
            JRadioButton radioButton_2 = new JRadioButton("\u8EAB\u9AD8");
            radioButton_2.setBounds(20, 91, 121, 23);
            this.add(radioButton_2);
            radioButton_2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    sortStudents(new HeightComparator());

                    StringBuilder sb = new StringBuilder();
                    for (Student st : students) {
                        sb.append(String.format("%s\t%s\t%.2f\t%.2f\t%.2f\t%s\r\n", st.id, st.name, st.height, st.weight, st.bmi, st.health));

                    }

                    textArea.setText(sb.toString());
                }

            });
            /*按体重进行排序*/
            JRadioButton radioButton_3 = new JRadioButton("\u4F53\u91CD");
            radioButton_3.setBounds(20, 117, 121, 23);
            this.add(radioButton_3);
            radioButton_3.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    sortStudents(new WeightComparator());

                    StringBuilder sb = new StringBuilder();
                    for (Student st : students) {
                        sb.append(String.format("%s\t%s\t%.2f\t%.2f\t%.2f\t%s\r\n", st.id, st.name, st.height, st.weight, st.bmi, st.health));

                    }

                    textArea.setText(sb.toString());
                }

            });
            /*按bmi值进行排序*/
            JRadioButton rdbtnBmi = new JRadioButton("bmi");
            rdbtnBmi.setBounds(20, 142, 121, 23);
            this.add(rdbtnBmi);
            rdbtnBmi.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    sortStudents(new BmiComparator());

                    StringBuilder sb = new StringBuilder();
                    for (Student st : students) {
                        sb.append(String.format("%s\t%s\t%.2f\t%.2f\t%.2f\t%s\r\n", st.id, st.name, st.height, st.weight, st.bmi, st.health));

                    }

                    textArea.setText(sb.toString());
                }

            });

        }
    }

    /*定义修改界面的信息*/
    class modifyPanel extends JPanel {

        public modifyPanel() {
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setBounds(100, 100, 450, 300);

            this.setBorder(new EmptyBorder(5, 5, 5, 5));
            setContentPane(this);
            this.setLayout(null);

            JLabel label = new JLabel("\u67E5\u8BE2\u5B66\u751F\u5B66\u53F7");
            label.setBounds(33, 36, 20, 8);
            this.add(label);

            textField = new JTextField();
            textField.setBounds(170, 15, 66, 21);
            this.add(textField);
            textField.setColumns(10);

            JButton button = new JButton("\u4FEE\u6539");
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                }
            });
            button.setBounds(313, 198, 111, 30);
            this.add(button);
            button.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    String id = textField.getText();
                    String name = textField_1.getText();
                    double height = Double.parseDouble(textField_2.getText());
                    double weight = Double.parseDouble(textField_3.getText());
                    boolean flag = false;
                    for (int i = 0; i < students.size(); i++) {
                        if (students.get(i).id.equals(id)) {
                            for (int j = i; j < students.size() - 1; j++) {/*将想要修改的信息传给该学生*/
                                students.get(j).id = id;
                                students.get(j).name = name;
                                students.get(j).height = height;
                                students.get(j).weight = weight;
                                students.get(j).bmi = students.get(j).weight / (students.get(j).weight * students.get(j).weight);
                                flag = true;

                            }
                        }

                    }
                    if (flag) {

                        JOptionPane.showMessageDialog(null, "修改成功！", "提示信息", JOptionPane.INFORMATION_MESSAGE);

                    } else {
                        JOptionPane.showMessageDialog(null, "未找到此学生！", "提示信息", JOptionPane.INFORMATION_MESSAGE);
                    }

                }
            });
            JLabel label_1 = new JLabel("\u4FEE\u6539\u7684\u5B66\u53F7");
            label_1.setBounds(33, 18, 77, 15);
            this.add(label_1);

            JLabel label_2 = new JLabel("\u59D3\u540D");
            label_2.setBounds(33, 73, 54, 15);
            this.add(label_2);

            textField_1 = new JTextField();
            textField_1.setBounds(170, 70, 66, 21);
            this.add(textField_1);
            textField_1.setColumns(10);

            JLabel label_3 = new JLabel("\u8EAB\u9AD8");
            label_3.setBounds(33, 126, 54, 15);
            this.add(label_3);

            textField_2 = new JTextField();
            textField_2.setBounds(170, 123, 66, 21);
            this.add(textField_2);
            textField_2.setColumns(10);

            JLabel label_4 = new JLabel("\u4F53\u91CD");
            label_4.setBounds(33, 163, 54, 15);
            this.add(label_4);

            textField_3 = new JTextField();
            textField_3.setBounds(170, 160, 66, 21);
            this.add(textField_3);
            textField_3.setColumns(10);
        }
    }

    private void back() {
        this.setContentPane(contentPane);
        setVisible(true);

    }

    private void delete() {
        this.setContentPane(new deletePanel());
        setVisible(true);

    }

    /*定义删除界面的信息*/
    class deletePanel extends JPanel {

        public deletePanel() {
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setBounds(100, 100, 450, 300);

            this.setBorder(new EmptyBorder(5, 5, 5, 5));
            setContentPane(contentPane);
            this.setLayout(null);

            JLabel label = new JLabel("\u67E5\u8BE2\u5B66\u751F\u5B66\u53F7");
            label.setBounds(33, 36, 20, 8);
            this.add(label);

            textField = new JTextField();
            textField.setBounds(170, 15, 66, 21);
            this.add(textField);
            textField.setColumns(10);

            JButton button = new JButton("\u5220\u9664");
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                }
            });
            button.setBounds(22, 65, 111, 30);
            this.add(button);
            button.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    String id = textField.getText();
                    boolean flag = false;
                    for (int i = 0; i < students.size(); i++) {
                        if (students.get(i).id.equals(id)) {/*对输入学号进行*/
                            for (int j = i; j < students.size() - 1; j++) {/*删除学生后，之后每一名学生的信息均前移一位*/
                                students.get(j).id = students.get(j + 1).id;
                                students.get(j).name = students.get(j + 1).name;
                                students.get(j).height = students.get(j + 1).height;
                                students.get(j).weight = students.get(j + 1).weight;
                                students.get(j).bmi = students.get(j + 1).bmi;
                                students.get(j).health = students.get(j + 1).health;
                                flag = true;

                            }
                        }

                    }
                    if (flag) {

                        JOptionPane.showMessageDialog(null, "删除成功！", "提示信息", JOptionPane.INFORMATION_MESSAGE);

                    } else {
                        JOptionPane.showMessageDialog(null, "未找到此学生！", "提示信息", JOptionPane.INFORMATION_MESSAGE);
                    }

                }
            });
            JLabel label_1 = new JLabel("\u5220\u9664\u7684\u5B66\u53F7");
            label_1.setBounds(33, 18, 77, 15);
            this.add(label_1);

        }
    }

    /*定义寻找界面的信息*/
    class FindPanel extends JPanel {

        public FindPanel() {
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setBounds(100, 100, 450, 300);
            setBorder(new EmptyBorder(5, 5, 5, 5));
            this.setLayout(null);

            JLabel label = new JLabel("\u67E5\u8BE2\u5B66\u751F\u5B66\u53F7");
            label.setBounds(33, 36, 20, 8);
            this.add(label);

            JLabel label_1 = new JLabel("\u67E5\u8BE2\u5B66\u751F\u5B66\u53F7");
            label_1.setBounds(33, 21, 94, 15);
            this.add(label_1);

            textField = new JTextField();
            textField.setBounds(170, 15, 66, 21);
            this.add(textField);
            textField.setColumns(10);

            JButton button = new JButton("\u67E5\u8BE2");
            button.setBounds(22, 65, 93, 23);
            this.add(button);
            textField_1 = new JTextField();
            textField_1.setBounds(170, 66, 400, 21);
            this.add(textField_1);
            textField_1.setColumns(10);
            button.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    String id = textField.getText();
                    boolean flag = false;
                    for (int i = 0; i < students.size(); i++) {/*遍历全部学生数据，如果id与要查询的id相等就输出该学生的信息，否则输出未找到*/
                        if (students.get(i).id.equals(id)) {
                            StringBuilder sb = new StringBuilder();
                            sb.append(String.format("%s\t%s\t%.2f\t%.2f\t%.2f\t%2s\r\n", students.get(i).id, students.get(i).name,
                                    students.get(i).height, students.get(i).weight, students.get(i).bmi, students.get(i).health));
                            textField_1.setText(sb.toString());
                            flag = true;
                        }

                    }
                    if (!flag) {
                        textField_1.setText("查无此人！");
                    }
                }
            });

        }
    }

    /*随机获取学生信息*/
    public Student[] genStudents(int N) {
        Student students[] = new Student[N];
        Random r = new Random();/*生成一个新的随机数*/
        double x = 0.0, y = 0.0;
        /*生成两百个随机学生信息*/
        for (int i = 0; i < 200; i++) {
            x = r.nextGaussian();
            y = r.nextGaussian();
            Random random = new Random();
            String id = String.valueOf(random.nextInt(10000) + 10000);
            while (isExists(id))/*对id是否存在进行判断*/ {
                id = String.valueOf(random.nextInt(10000) + 10000);
            }
            Student st = new Student(id,
                    genRandomString(6), (1.75 + x * 0.1), (60.0 + y * 5));
            students[i] = st;
        }
        return students;
    }

    /*随机生成学生的名字*/
    private String genRandomString(int length) {
        // TODO Auto-generated method stub
        String str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(26);
            sb.append(str.charAt(number));
        }
        return sb.toString();
    }

    /**
     * Launch the application.
     */
    /*主函数，运行整个程序*/
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    GUIFileBMI frame = new GUIFileBMI();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    /*创建程序主界面*/
    public GUIFileBMI() {

        setTitle("\u5B66\u751F\u4FE1\u606F\u8F93\u5165");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        /*定义各功能的按键*/
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        JMenuItem menuItem_1 = new JMenuItem("学生信息显示及录入");
        menuBar.add(menuItem_1);
        JMenuItem menuItem = new JMenuItem("学生信息排序");
        

        JMenu a = new JMenu("学生信息维护");
        JMenu b = new JMenu("BMI统计");
        JMenu menu3 = new JMenu("菜单");
        JMenuItem menu2 = new JMenuItem("统计数据显示");
        menuItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                paixu();
            }
        });
        menu3.add(menuItem);
        menu2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                statics();
            }
        });
        JMenuItem c = new JMenuItem("bmi图表");
        c.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JFreeChart chart = ChartFactory.createXYBarChart("BMI Statistics",
                        "Intervals", false, "Number of Students",
                        BmiDataset(), PlotOrientation.VERTICAL,
                        true, false, false);

                ChartFrame frame = new ChartFrame("BMI Statistics", chart);
                frame.pack();
                frame.setVisible(true);

            }
        });
        JMenuItem jmi1 = new JMenuItem("查询");
        jmi1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                findStudent();
            }
        });
        JMenuItem jmi2 = new JMenuItem("修改");
        jmi2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modify();
            }
        });
        JMenuItem jmi3 = new JMenuItem("删除");
        jmi3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                delete();
            }
        });
        a.add(jmi1);
        a.add(jmi2);
        a.add(jmi3);
        b.add(menu2);
        b.add(c);
        menu3.add(a);
        menu3.add(b);
        menuBar.add(menu3);

        /*将功能项目添加在界面中*/
        JToolBar toolBar = new JToolBar();
        menuBar.add(toolBar);

        JButton button_3 = new JButton("\u8FD4\u56DE");
        button_3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                back();
            }
        });
        /*定义各个标签按钮所在的位置*/
        toolBar.add(button_3);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        label_2 = new JLabel("");
        label_2.setBounds(5, 256, 424, 0);
        contentPane.add(label_2);

        textField = new JTextField();
        textField.setBounds(55, 43, 66, 21);
        contentPane.add(textField);
        textField.setColumns(10);

        JLabel label = new JLabel("\u5B66\u53F7");
        label.setBounds(5, 46, 54, 15);
        contentPane.add(label);

        JLabel label_1 = new JLabel("\u59D3\u540D");
        label_1.setBounds(5, 74, 54, 15);
        contentPane.add(label_1);

        textField_1 = new JTextField();
        textField_1.setBounds(55, 71, 66, 21);
        contentPane.add(textField_1);
        textField_1.setColumns(10);

        JLabel label_3 = new JLabel("\u8EAB\u9AD8");
        label_3.setBounds(5, 98, 54, 15);
        contentPane.add(label_3);

        textField_2 = new JTextField();
        textField_2.setBounds(55, 95, 66, 21);
        contentPane.add(textField_2);
        textField_2.setColumns(10);

        JLabel label_4 = new JLabel("\u4F53\u91CD");
        label_4.setBounds(5, 123, 54, 15);
        contentPane.add(label_4);

        textField_3 = new JTextField();
        textField_3.setBounds(55, 123, 66, 21);
        contentPane.add(textField_3);
        textField_3.setColumns(10);

        JButton button = new JButton("\u4FDD\u5B58\u6570\u636E");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String id = textField.getText();

                String name = textField_1.getText();
                double height = Double.parseDouble(textField_2.getText());
                double weight = Double.parseDouble(textField_3.getText());
                Student student = new Student(id, name, height, weight);
                student.bmi = student.weight / (student.height * student.height);
                students.add(student);
                button.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        if (isExists(id)) {
                            students.remove(students.size() - 1);
                            JOptionPane.showMessageDialog(null, "学号重复！", "提示信息", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "保存成功", "提示信息", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                });
            }
        });
        button.setBounds(5, 148, 93, 23);
        contentPane.add(button);

        JLabel label_5 = new JLabel("\u8F93\u5165\u5B66\u751F\u4FE1\u606F");
        label_5.setBounds(5, 10, 116, 37);
        contentPane.add(label_5);

        JButton button_1 = new JButton("\u663E\u793A\u5B66\u751F\u4FE1\u606F");

        JTextArea textArea = new JTextArea();
        textArea.setBounds(180, 42, 400, 500);
        JScrollPane jp = new JScrollPane(textArea);
        jp.setBounds(180, 42, 600, 500);
        contentPane.add(jp);
        button_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                StringBuilder sb = new StringBuilder();
                for (Student st : students) {
                    sb.append(String.format("%s\t%s\t%.2f\t%.2f\t%.2f\t%s\r\n", st.id, st.name, st.height, st.weight, st.bmi, st.health));

                }

                textArea.setText(sb.toString());

            }
        });
        button_1.setBounds(196, 17, 121, 23);
        contentPane.add(button_1);

        JButton button_2 = new JButton("\u968F\u673A\u83B7\u53D6\u5B66\u751F");
        button_2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Student student[] = new Student[200];
                student = genStudents(200);
                for (int i = 0; i < 200; i++) {
                    students.add(student[i]);
                    students.get(i).bmi = students.get(i).weight / (students.get(i).height * students.get(i).height);
                }
            }

        });
        button_2.setBounds(5, 186, 105, 23);
        contentPane.add(button_2);

    }

    /*定义学生的剋，用于存储学生信息*/
    class Student {

        public String id;
        public String name;
        public double bmi, height, weight;
        public String health;

        /*定义学生创建方法*/
        public Student(String id, String name, double height, double weight) {
            this.id = id;
            this.name = name;
            this.height = height;
            this.weight = weight;
            this.bmi = weight / height / height;
            this.health = checkHealth(this.bmi);
        }

        public Student(String id) {
            this.id = id;
        }

        /*设置学生的名字*/
        public void setName(String name) {
            this.name = name;
        }

        /*设置学生的学号*/
        public void setId(String id) {
            this.id = id;
        }

        /*设置学生的身高*/
        public void setHeight(double height) {
            this.height = height;
        }

        /*设置学生的体重*/
        public void setWeight(double weight) {
            this.weight = weight;
        }

        /*设置学生的bmi*/
        public void setBmi(double bmi) {
            this.bmi = bmi;
        }

        /*获取学生的名字*/
        public String getName() {
            return this.name;
        }

        /*获取学生的id*/
        public String getId() {
            return this.id;
        }

        /*获取学生的体重*/
        public double getWeight() {
            return this.weight;
        }

        /*获取学生的身高*/
        public double getHeight() {
            return this.height;
        }

        /*获取学生的bmi*/
        public double getBmi() {
            return this.bmi;
        }

        /*
        根据bmi值的范围确定学生身体状况
         */
        public String checkHealth(double bmis) {
            if (bmis < 18.5) {
                return "Underweight";
            } else if (bmis < 23) {
                return "Normal Range";
            } else if (bmis < 25) {
                return "Overweight-At Risk";
            } else if (bmis < 30) {
                return "Overweight-Moderately Obese";
            } else {
                return "Overweight-Severely Obese";
            }
        }
    }
}
